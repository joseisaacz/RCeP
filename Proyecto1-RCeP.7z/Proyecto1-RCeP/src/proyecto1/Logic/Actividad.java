package proyecto1.Logic;

import java.util.*;

public class Actividad {
    private String id;
    private int duracion;
    private int IC;
    public int contador;
//    private int TC;
    private int IL;
    private int TL;
    public  int x;
    public int y;
   
    private ArrayList<Actividad> antecesoras;    
    private ArrayList<Actividad> sucesoras;
       public Actividad(){
            id=" ";
            duracion=0;
            antecesoras=new ArrayList();
            sucesoras=new ArrayList();
            x=0;
            y=0;
            IC=0;
//            TC=0;
            IL=0;
            TL=0;
            contador=0;
        }
        public Actividad(String _id, int _duracion, int _x, int _y){
            id=_id;
            duracion=_duracion;
         antecesoras=new ArrayList();
         sucesoras=new ArrayList();
         x=_x;
         y=_y;
         IC=0;
//         TC=0;
         IL=0;
         TL=0;
        contador=0;
        }
        public String getId(){
            return id;
        }
        public void setId(String _id){
            id=_id;
        }
        public int getDuracion(){
            return duracion;
        }
        public void setDuracion(int _duracion){
            duracion=_duracion;
        }
      public ArrayList<Actividad> getAntecesoras(){
          return antecesoras;
      }
      public void setAnteceoras(ArrayList<Actividad> _antecesoras){
          antecesoras=_antecesoras;
      }
      public ArrayList<Actividad> getSucesoras(){
          return sucesoras;
      }
      public void setSucesoras(ArrayList<Actividad> _sucesoras){
          sucesoras=_sucesoras;
      }
      public int getX(){
          return x;
      }
      public void setX(int _x){
          x=_x;
      }
      public int gety(){
          return y;
      }
      public void setY(int _y){
          y=_y;
      }
      public boolean equals(Actividad obj){
          return this.getId().equals(obj.getId());
      }
      public void agregarS(Actividad _sucesora){
          sucesoras.add(_sucesora);
      }
      public void agregarA(Actividad _antecesora){
          antecesoras.add(_antecesora);
      }
      public int getIC(){
          return IC;
      }
      public void setIC(int _IC){
          IC=_IC;
      }
      public int getIL(){
          return IL;
      }
      public void setIL(int _IL){
          IL=_IL;
      }
      public int getcontador(){
          return contador;
      }
//      public int  getTC(){
//          return TC;
//      }
//      public void setTC(int _TC){
//          TC=_TC;
//      }
      public int getTL(){
          return TL;
      }
      public void setTL(int _TL){
          TL=_TL;
      }
      public int TC(){
          return this.IC+this.duracion;
      }
      public int TL(){
          return this.IL+this.duracion;
      }
      public boolean holgura(){
          int x=IC-IL;
          int y=this.TC()-this.TL();      
          return ((x==0)&&(y==0));
      }
      @Override
      public String toString(){
          String x=("Id: "+this.getId()+"  "+this.getIC()+" "+this.TC()+" "+this.getIL()+" "+this.TL()/*+"Duracion: "+this.getDuracion()*/);
          return x;
      }
      
}