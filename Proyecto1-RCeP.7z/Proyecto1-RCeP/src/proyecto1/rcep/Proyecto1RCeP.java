package proyecto1.rcep;

import java.io.IOException;
import proyecto1.Logic.Actividad;
import proyecto1.Logic.Proyecto;
import proyecto1.Data.ReadAndWrite;
import proyecto1.Vista.View;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import proyecto1.Vista.Controller;
import proyecto1.Vista.Model;

public class Proyecto1RCeP {

    public static void main(String[] args)  {
        Proyecto pro = new Proyecto();
        Model m=new Model();
        View view=new View();
        Controller controller=new Controller(m, view);
        view.setVisible(true);
        try {
            ReadAndWrite read=new ReadAndWrite("datos.xml");
            for(int i=0; i<read.getas("Actividad").getLength();i++){
                Actividad act=read.read("id", "duracion", i);
                pro.agregar(act);
            }
//                read.setas("Relacion");
               for(int j=0; j<read.getas("Relacion").getLength();j++){
                   String Antecesor=read.readRelacion(j, "actividad");
                   String Sucesor= read.readRelacion(j, "sucesor");
                   pro.agregarAnt(Antecesor, Sucesor);
                   pro.agregarSuc(Sucesor, Antecesor);
               } 
               pro.AddStart();
               pro.AddEnd();
               pro.CPM();
        }catch(Exception e){
            System.out.println(e.getCause());
        }
         m.setP(pro);
//               System.in.read();
               
    }
    
}