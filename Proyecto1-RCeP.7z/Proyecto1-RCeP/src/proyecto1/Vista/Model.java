/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1.Vista;

import java.util.Observable;
import proyecto1.Logic.Actividad;
import proyecto1.Logic.Proyecto;

/**
 *
 * @author jisaa
 */
public class Model extends Observable {
    Proyecto p;

    public Model(Proyecto p) {
        this.p = p;
    }

    public Model() {
        p=new Proyecto();
    }

    public Proyecto getP() {
        return p;
    }

    public void setP(Proyecto p) {
        this.p = p;
    }
    public void agregrarAct( Actividad a){
        p.agregar(a);
        this.setChanged();
        this.notifyObservers();
    }
}
