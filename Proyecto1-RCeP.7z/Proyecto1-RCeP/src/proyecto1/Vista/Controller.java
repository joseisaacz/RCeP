/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1.Vista;

import proyecto1.Logic.Actividad;

/**
 *
 * @author jisaa
 */
public class Controller {
    Model model;
    View view;
    public Controller(Model _model, View _view){
        model =_model;
        view=_view;
        _view.setmodel(_model);
        _view.setcontroller(this);
    }
    public void agregarActividad(String id, int duracion, int x, int y){
        Actividad a=new Actividad(id,duracion,x,y);
        model.agregrarAct(a);
    }
}
